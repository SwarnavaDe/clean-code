package com.epam.engx.cleancode.naming.task1.thirdpartyjar;

public interface CollectionService {
    boolean isEligibleForCollection(Order order);
}
