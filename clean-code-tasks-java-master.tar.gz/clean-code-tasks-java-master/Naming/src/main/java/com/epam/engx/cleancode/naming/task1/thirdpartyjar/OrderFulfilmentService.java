package com.epam.engx.cleancode.naming.task1.thirdpartyjar;

import java.util.List;

public interface OrderFulfilmentService {
    void fulfilProducts(List<Product> products);
}
