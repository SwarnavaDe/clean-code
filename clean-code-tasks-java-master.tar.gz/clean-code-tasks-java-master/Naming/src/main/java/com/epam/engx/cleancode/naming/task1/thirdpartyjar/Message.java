package com.epam.engx.cleancode.naming.task1.thirdpartyjar;

public enum Message {
    IMPOSSIBLE_TO_COLLECT, READY_FOR_COLLECT
}
