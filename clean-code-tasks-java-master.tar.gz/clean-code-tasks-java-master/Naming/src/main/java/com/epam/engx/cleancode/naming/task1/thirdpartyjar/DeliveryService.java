package com.epam.engx.cleancode.naming.task1.thirdpartyjar;

public interface DeliveryService {
    boolean isDeliverable();
}
