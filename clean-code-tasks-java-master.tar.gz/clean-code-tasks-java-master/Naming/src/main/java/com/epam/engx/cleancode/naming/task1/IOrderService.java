package com.epam.engx.cleancode.naming.task1;

import com.epam.engx.cleancode.naming.task1.thirdpartyjar.Order;

public interface IOrderService {
    void submitOrder(Order pOrder);
}
