package com.epam.engx.cleancode.errorhandling.task1.thirdpartyjar;

public interface OrderHistory {
}
