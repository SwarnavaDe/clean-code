package com.epam.engx.cleancode.functions.task1.thirdpartyjar;

public interface PasswordChecker {

    CheckStatus validate(String password);
}
