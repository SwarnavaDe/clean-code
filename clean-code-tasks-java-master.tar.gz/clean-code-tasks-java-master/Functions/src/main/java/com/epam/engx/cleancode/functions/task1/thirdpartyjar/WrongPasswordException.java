package com.epam.engx.cleancode.functions.task1.thirdpartyjar;

public class WrongPasswordException extends RuntimeException {
}
