package com.epam.engx.cleancode.functions.task3.thirdpartyjar;

public interface SessionManager {

    void setCurrentUser(User user);

}
