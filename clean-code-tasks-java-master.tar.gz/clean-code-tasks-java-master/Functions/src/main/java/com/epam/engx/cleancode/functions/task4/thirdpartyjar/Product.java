package com.epam.engx.cleancode.functions.task4.thirdpartyjar;

public interface Product {

    double getProductPrice();

    boolean isAvailable();
}
