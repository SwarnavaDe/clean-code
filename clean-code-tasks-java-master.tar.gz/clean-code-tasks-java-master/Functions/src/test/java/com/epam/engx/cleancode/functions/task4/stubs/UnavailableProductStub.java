package com.epam.engx.cleancode.functions.task4.stubs;

public class UnavailableProductStub extends AbstractProductStub {
    @Override
    public boolean isAvailable() {
        return false;
    }
}
